package co.edu.unab.apirestappointments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestAppointmentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiRestAppointmentsApplication.class, args);
	}
}